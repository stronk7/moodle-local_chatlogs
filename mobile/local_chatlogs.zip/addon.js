angular.module('mm.addons.local_chatlogs', [])
.config(["$stateProvider", "$mmSideMenuDelegateProvider", function($stateProvider, $mmSideMenuDelegateProvider) {
    $stateProvider
    .state('site.local_chatlogs-list', {
           url: '/local_chatlogs/list',
           views: {
               'site': {
                   templateUrl: '$ADDONPATH$/templates/list.html',
                   controller: 'mmaChatlogsListCtrl'
               }
           }
       })
       .state('site.local_chatlogs-chat', {
        url: '/local_chatlogs/chat',
        views: {
            'site': {
                templateUrl: '$ADDONPATH$/templates/chat.html',
                controller: 'mmaChatlogsChatCtrl'
            }
        },
        params: { conversationid: null }
    });
    $mmSideMenuDelegateProvider.registerNavHandler('mmaLocalChatlogs', '$mmaLocalChatlogsHandlers.sideMenuNav', 10);
}]);

angular.module('mm.addons.local_chatlogs')
.controller('mmaChatlogsChatCtrl', ["$scope", "$stateParams", "$mmaLocalChatlogs", "$mmUtil", function($scope, $stateParams, $mmaLocalChatlogs, $mmUtil) {
    var conversationid = $stateParams.conversationid;
    $scope.title = "Chatlogs";
    $scope.loaded = false;
    $scope.messages = [];
    $scope.classSwitched = false;
    $scope.showDate = function(message, prevMessage) {
        if (!prevMessage) {
            return true;
        }
        return !moment(message.timesent * 1000).isSame(prevMessage.timesent * 1000, 'day');
    };
    $scope.switchStyle = function(message, prevMessage) {
        if (!prevMessage) {
            $scope.classSwitched = false;
            return $scope.classSwitched;
        }
        var nickChanged = (message.fromnick != prevMessage.fromnick);
        if ($scope.classSwitched){
            $scope.classSwitched = !nickChanged;
        } else {
            $scope.classSwitched = nickChanged;
        }
        return $scope.classSwitched;
    };
    return $mmaLocalChatlogs.getConversationMessages(conversationid).then(function(chatlist) {
        $scope.messages = chatlist;
    }, function(error) {
        if (typeof error === 'string') {
            $mmUtil.showErrorModal(error);
        } else {
            $mmUtil.showErrorModal('mma.local_chatlogs.errorwhileretrievingmessages', true);
        }
    }).finally(function() {
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.local_chatlogs')
.controller('mmaChatlogsListCtrl', ["$scope", "$stateParams", "$mmaLocalChatlogs", function($scope, $stateParams, $mmaLocalChatlogs) {
    $scope.loaded = false;
    return $mmaLocalChatlogs.getConversationList().then(function(chatlist) {
        $scope.chats = chatlist;
        $scope.loaded = true;
    });
}]);

angular.module('mm.addons.local_chatlogs')
.factory('$mmaLocalChatlogsHandlers', ["$state", function($state) {
  var self = {};
  self.isEnabled = function() {
      return true;
  };
  self.isEnabledForUser = function(user, courseId) {
     return true;
  };
  self.sideMenuNav = function() {
      var self = {};
            self.isEnabled = function() {
          return true;
      }
            self.getController = function() {
                    return function($scope, $translate) {
              $scope.icon = 'ion-bug';
              $scope.title = $translate.instant('mma.local_chatlogs.title');
              $scope.state = 'site.local_chatlogs-list';
          };
      }
      return self;
  };
  return self;
}]);

angular.module('mm.addons.local_chatlogs')
.factory('$mmaLocalChatlogs', ["$q", "$mmSite", "$mmFS", "$mmUtil", "$mmSitesManager", function($q, $mmSite, $mmFS, $mmUtil, $mmSitesManager) {
    var self = {};
        self.getConversationList = function() {
        var params = {};
        var preSets = {getFromCache: false};
        return $mmSite.read('local_chatlogs_get_conversation_list', params, preSets).then(function(response) {
            if (response.conversations) {
                return response.conversations
            }
            return $q.reject();
        });
    };
    self.getConversationMessages = function(conversationid) {
        var params = {conversationid: conversationid};
        var preSets = {getFromCache: false};
        return $mmSite.read('local_chatlogs_get_conversation_messages', params, preSets).then(function(response) {
            if (response.messages) {
                return response.messages
            }
            return $q.reject();
        });
    };
    return self;
}]);
