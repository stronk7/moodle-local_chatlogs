angular.module('mm.addons.local_chatlogs')

.controller('mmaChatlogsChatCtrl', function($scope, $stateParams, $mmaLocalChatlogs, $mmUtil) {
    var conversationid = $stateParams.conversationid;

    $scope.title = "Chatlogs";
    $scope.loaded = false;
    $scope.messages = [];
    $scope.classSwitched = false;

    $scope.showDate = function(message, prevMessage) {
        if (!prevMessage) {
            return true;
        }

        // Check if day has changed.
        return !moment(message.timesent * 1000).isSame(prevMessage.timesent * 1000, 'day');
    };

    $scope.switchStyle = function(message, prevMessage) {
        if (!prevMessage) {
            $scope.classSwitched = false;
            return $scope.classSwitched;
        }
        var nickChanged = (message.fromnick != prevMessage.fromnick);

        if ($scope.classSwitched){
            $scope.classSwitched = !nickChanged;
        } else {
            $scope.classSwitched = nickChanged;
        }

        return $scope.classSwitched;
    };

    return $mmaLocalChatlogs.getConversationMessages(conversationid).then(function(chatlist) {
        $scope.messages = chatlist;
    }, function(error) {
        if (typeof error === 'string') {
            $mmUtil.showErrorModal(error);
        } else {
            $mmUtil.showErrorModal('mma.local_chatlogs.errorwhileretrievingmessages', true);
        }
    }).finally(function() {
        $scope.loaded = true;
    });
});
